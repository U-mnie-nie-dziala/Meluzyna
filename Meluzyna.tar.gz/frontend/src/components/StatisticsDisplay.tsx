import { useEffect, useState } from 'react';
import {
  TrendingUp,
  TrendingDown,
  BarChart3,
  Activity,
  AlertCircle,
  Award,
} from 'lucide-react';
import { AnalysisData, Sector } from '../types';
// import { PerformanceTab } from './tabs/PerformanceTab'; // To już nie jest potrzebne
import SectorRanking from '../SectorRanking'; // <--- NOWY IMPORT

interface StatisticsDisplayProps {
  data: AnalysisData;
  sector: Sector;
}

// Zaktualizowałem typy, żeby pasowały do Twoich tabów
type Tab = 'overview' | 'performance' | 'media' | 'stock-market';

export default function StatisticsDisplay({ data, sector }: StatisticsDisplayProps) {
  const [activeTab, setActiveTab] = useState<Tab>('overview');

  const tabs = [
    { id: 'overview' as Tab, label: 'Przegląd', icon: BarChart3 },
    { id: 'performance' as Tab, label: 'Ranking Sektorów', icon: Activity },
    { id: 'media' as Tab, label: 'Media', icon: AlertCircle }, // Wcześniej w kodzie było 'risk', ale w tabach 'media'
    { id: 'stock-market' as Tab, label: 'Giełda', icon: AlertCircle },
  ];

  const sectorName = sector.charAt(0).toUpperCase() + sector.slice(1);

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
      <div className="border-b border-slate-200 bg-slate-50 px-6 py-4">
        <h2 className="text-xl font-bold text-slate-900">
          Analiza sektora {sectorName}
        </h2>
        <p className="text-sm text-slate-600 mt-1">
          Szczegółowe dane finansowe i kluczowe wnioski
        </p>
      </div>

      <div className="border-b border-slate-200">
        <div className="flex">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex-1 px-6 py-4 font-semibold text-sm transition-all relative
                          ${activeTab === tab.id
                    ? 'text-blue-600 bg-white'
                    : 'text-slate-600 bg-slate-50 hover:bg-slate-100'
                  }`}
              >
                <div className="flex items-center justify-center gap-2">
                  <Icon className="w-4 h-4" />
                  {tab.label}
                </div>
                {activeTab === tab.id && (
                  <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-600" />
                )}
              </button>
            );
          })}
        </div>
      </div>

      <div className="p-6">
        {activeTab === 'overview' && <OverviewTab data={data} />}
        
        {/* TUTAJ WSTAWIŁEM TWÓJ RANKING */}
        {activeTab === 'performance' && <SectorRanking />}
        
        {/* Poprawiłem logikę dla taba Media/Risk, bo w kodzie było niespójnie */}
        {activeTab === 'media' && <RiskTab data={data} />}
        
        {activeTab === 'stock-market' && <StockMarket sector={sector} />}
      </div>
    </div>
  );
}


function StockMarket({ sector }: { sector: Sector }) {
  const [latest, setLatest] = useState(null);

  useEffect(() => {
    const fetchLatest = async () => {
      try {
        const res = await fetch(`http://127.0.0.1:8000/markets/scores/${sector}`);
        const data = await res.json();
        setLatest(data);
      } catch (error) {
        console.error("Error fetching sector score:", error);
      }
    };

    if (sector) {
      fetchLatest();
    }
  }, [sector]);

  return (
    <div>
      <h3 className="text-lg font-bold mb-4">Dane Giełdowe ({sector})</h3>
      {latest ? (
        <pre className="bg-slate-50 p-4 rounded-lg text-sm overflow-auto">
            {JSON.stringify(latest, null, 2)}
        </pre>
      ) : (
        "Ładowanie..."
      )}
    </div>
  );
}


function OverviewTab({ data }: { data: AnalysisData }) {
  // Determine color for large score
  const isNoData = data.combinedScore === -1;

  let scoreColor = '';
  let scoreBg = '';

  if (isNoData) {
    scoreColor = 'text-slate-400';
    scoreBg = 'bg-slate-50 border-slate-200';
  } else {
    scoreColor = data.combinedScore >= 60 ? 'text-emerald-600' : data.combinedScore >= 40 ? 'text-yellow-600' : 'text-red-600';
    scoreBg = data.combinedScore >= 60 ? 'bg-emerald-50 border-emerald-200' : data.combinedScore >= 40 ? 'bg-yellow-50 border-yellow-200' : 'bg-red-50 border-red-200';
  }

  // Icon logic for Combined Score: Same behavior as ScoreCards (Result-based)
  let CombinedIcon = AlertCircle;
  if (!isNoData) {
    if (data.combinedScore >= 60) CombinedIcon = TrendingUp;
    else if (data.combinedScore >= 40) CombinedIcon = Activity;
    else CombinedIcon = TrendingDown;
  }

  return (
    <div className="space-y-6">
      {/* Large Combined Score Indicator */}
      <div className={`rounded-2xl p-6 border-2 flex items-center justify-between ${scoreBg}`}>
        <div>
          <h3 className="text-lg font-bold text-slate-800 mb-1">Syntetyczny Wskaźnik Sektora</h3>
          <p className="text-slate-600 text-sm max-w-md">
            Zbiorczy wskaźnik łączący ocenę bezpieczeństwa giełdowego, opinie mediów, demografię firm i wskaźniki ekonomiczne GUS.
          </p>
        </div>
        <div className="flex items-center gap-4">
          <div className="text-right">
            <span className={`block text-5xl font-black ${scoreColor}`}>
              {isNoData ? '--' : data.combinedScore}
            </span>
            <span className="text-sm font-semibold text-slate-500 uppercase tracking-wider">
              {isNoData ? 'Brak danych' : '/ 100 pkt'}
            </span>
          </div>
          <CombinedIcon className={`w-12 h-12 ${scoreColor}`} />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <ScoreCard
          label="Demografia firm CEIDG"
          value={data.demographics}
        />
        <ScoreCard
          label="Tempo wzrostu GUS"
          value={data.growthSpeed}
        />
        <ScoreCard
          label="Media"
          value={data.mediaSentiment}
        />
        <ScoreCard
          label="Giełda"
          value={data.stockMarketSentiment}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-slate-50 rounded-lg p-5 border border-slate-200">
          <h3 className="text-sm font-semibold text-slate-700 mb-4">Wskaźniki Finansowe</h3>
          <div className="space-y-3">
            <RatioRow label="Marża Zysku" value={`${data.profitMargin}%`} />
            <RatioRow label="ROE" value={`${data.roe}%`} />
            <RatioRow label="Wskaźnik C/Z (P/E)" value={data.peRatio.toFixed(2)} />
            <RatioRow label="Stopa Dywidendy" value={`${data.dividendYield}%`} />
          </div>
        </div>

        <div className="bg-slate-50 rounded-lg p-5 border border-slate-200">
          <h3 className="text-sm font-semibold text-slate-700 mb-4 flex items-center gap-2">
            <Award className="w-4 h-4" />
            Liderzy Sektora
          </h3>
          <div className="space-y-3">
            {data.topPerformers.map((performer, index) => (
              <div key={index} className="flex items-center justify-between">
                <span className="text-sm text-slate-700 font-medium">{performer.name}</span>
                <span
                  className={`text-sm font-semibold ${performer.performance > 0 ? 'text-emerald-600' : 'text-red-600'
                    }`}
                >
                  {performer.performance > 0 ? '+' : ''}
                  {performer.performance}%
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}



function RiskTab({ data }: { data: AnalysisData }) {
  const getRiskColor = (level: string) => {
    switch (level) {
      case 'Low':
        return 'text-emerald-600 bg-emerald-100';
      case 'Medium':
        return 'text-amber-600 bg-amber-100';
      case 'High':
        return 'text-red-600 bg-red-100';
      default:
        return 'text-slate-600 bg-slate-100';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between p-6 bg-slate-50 rounded-lg border border-slate-200">
        <div>
          <h3 className="text-sm font-semibold text-slate-700 mb-1">Poziom Ryzyka</h3>
          <p className="text-2xl font-bold text-slate-900">{data.riskLevel}</p>
        </div>
        <div className={`px-4 py-2 rounded-lg font-semibold ${getRiskColor(data.riskLevel)}`}>
          {data.riskLevel} Risk
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <RiskMetricCard
          label="Wskaźnik Zadłużenia"
          value={data.debtToEquity.toFixed(2)}
          optimal="< 2.0"
          status={data.debtToEquity < 2 ? 'good' : data.debtToEquity < 3 ? 'moderate' : 'high'}
        />
        <RiskMetricCard
          label="Wskaźnik C/Z"
          value={data.peRatio.toFixed(2)}
          optimal="15-25"
          status={
            data.peRatio >= 15 && data.peRatio <= 25
              ? 'good'
              : data.peRatio < 15 || data.peRatio <= 35
                ? 'moderate'
                : 'high'
          }
        />
      </div>

      <div className="bg-amber-50 border border-amber-200 rounded-lg p-5">
        <div className="flex gap-3">
          <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
          <div>
            <h4 className="font-semibold text-amber-900 mb-1">Uwagi dot. ryzyka</h4>
            <p className="text-sm text-amber-800 leading-relaxed">
              Monitoruj poziom zadłużenia i wskaźniki wyceny. Zalecana jest dywersyfikacja
              portfela w ramach sektora, aby ograniczyć ryzyko związane z pojedynczymi spółkami.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function RiskMetricCard({ label, value, optimal, status }: { label: string, value: string, optimal: string, status: 'good' | 'moderate' | 'high' }) {
    const getStatusColor = () => {
        if (status === 'good') return 'text-emerald-600 bg-emerald-50 border-emerald-200';
        if (status === 'moderate') return 'text-amber-600 bg-amber-50 border-amber-200';
        return 'text-red-600 bg-red-50 border-red-200';
    }

    return (
        <div className={`p-4 rounded-lg border ${getStatusColor()}`}>
            <p className="text-xs font-semibold opacity-80 uppercase mb-1">{label}</p>
            <div className="flex justify-between items-end">
                <p className="text-2xl font-bold">{value}</p>
                <p className="text-xs opacity-80">Optymalnie: {optimal}</p>
            </div>
        </div>
    )
}

function ScoreCard({
  label,
  value,
}: {
  label: string;
  value: number;
}) {
  const isNoData = value === -1;

  // Color scale logic: Red (0) -> Yellow (50) -> Green (100)
  const getColorClass = (val: number) => {
    if (isNoData) return 'text-slate-400';
    if (val >= 60) return 'text-emerald-500'; // High/Good
    if (val >= 40) return 'text-yellow-500';  // Mid/Neutral
    return 'text-red-500';                    // Low/Bad
  };

  const getBgClass = (val: number) => {
    if (isNoData) return 'bg-slate-50 border-slate-200';
    if (val >= 60) return 'bg-emerald-50 border-emerald-100';
    if (val >= 40) return 'bg-yellow-50 border-yellow-100';
    return 'bg-red-50 border-red-100';
  };

  // Icon logic: Zigzag arrows
  const getTrendIcon = (val: number) => {
    if (isNoData) return <AlertCircle className="w-8 h-8 text-slate-300" />;
    if (val >= 60) return <TrendingUp className="w-8 h-8" />;
    if (val >= 40) return <Activity className="w-8 h-8" />; // Horizontal-ish zigzag
    return <TrendingDown className="w-8 h-8" />;
  };

  const colorClass = getColorClass(value);
  const bgClass = getBgClass(value);

  return (
    <div className={`border rounded-lg p-5 hover:shadow-md transition-all ${bgClass}`}>
      <div className="flex items-center justify-between mb-3">
        {/* Increased Label Size (text-lg font-bold) */}
        <p className="text-lg font-bold text-slate-700">{label}</p>

        {/* Only Trend Icon - No left icon */}
        <div className={colorClass}>
          {getTrendIcon(value)}
        </div>
      </div>

      <div className="flex items-end gap-2">
        {isNoData ? (
          <p className="text-xl font-bold text-slate-400">Brak danych</p>
        ) : (
          <p className={`text-2xl font-bold ${colorClass}`}>{value}/100</p>
        )}
      </div>

      {/* Progress Bar Visual - Hidden if No Data */}
      {!isNoData && (
        <div className="w-full bg-slate-200 h-1.5 rounded-full mt-3 overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-500 ${valToTailwind(value)}`}
            style={{ width: `${value}%` }}
          />
        </div>
      )}
    </div>
  );
}

// Helper for progress bar color
function valToTailwind(val: number) {
  if (val >= 60) return 'bg-emerald-500';
  if (val >= 40) return 'bg-yellow-500';
  return 'bg-red-500';
}

function RatioRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-sm text-slate-600">{label}</span>
      <span className="text-sm font-semibold text-slate-900">{value}</span>
    </div>
  );
}
